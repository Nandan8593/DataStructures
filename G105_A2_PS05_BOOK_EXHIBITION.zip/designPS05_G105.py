'''
Developers : PORURI V S HARI HARA NANDAN, SIBEN NAYAK

To solve this problem efficiently using a greedy technique, we can follow these steps:

1. Initially, establish a foundational price for each book.
2. In the forward progression, ascertain relative review scores and adjust prices upward as necessary.
3. An inverse sweep, from the array's end to its beginning, refines these prices, ironing out any discrepancies from the first pass.

'''
import os

# Function to calculate the minimum total price for a list of reviews using greedy method.


def min_price_greedy(reviews):
    n = len(reviews)

    # Initialize the price array with all values set to 1
    prices = [1] * n

    # Forward pass
    for i in range(1, n):
        if reviews[i] > reviews[i - 1]:
            prices[i] = prices[i - 1] + 1

    # Backward pass
    for i in range(n - 2, -1, -1):
        if reviews[i] > reviews[i + 1] and prices[i] <= prices[i + 1]:
            prices[i] = prices[i + 1] + 1

    return sum(prices)


# Function to calculate the minimum total price for a list of reviews using dynamic programming. This is just for reference and is not used in the main method.
def min_price_dp(reviews):
    n = len(reviews)

    # Initialize the dp array with all values set to 1
    dp = [1] * n

    # From left to right
    for i in range(1, n):
        if reviews[i] > reviews[i - 1]:
            dp[i] = dp[i - 1] + 1

    # From right to left
    for i in range(n - 2, -1, -1):
        if reviews[i] > reviews[i + 1]:
            dp[i] = max(dp[i], dp[i + 1] + 1)

    return sum(dp)


# Main function to read input from a file, perform calculations, and write results to an output file
def main():
    try:
        output_file = 'outputPS05.txt'
        input_file = 'inputPS05.txt'

        # If the output file exists, remove it to start fresh
        if os.path.exists(output_file):
            os.remove(output_file)

        file_object = open(input_file)

        for i in file_object:
            # Extract row from each line in the input file
            row_ = i.split("=")[1]
            row_ = eval(row_)

            # Check for negative numbers in the row
            has_negative = any(not isinstance(num, int)
                               or num < 0 for num in row_)
            if has_negative:
                print(
                    "ERROR: This Algorithm doesn't support elements other than positive integers.")
                exit(1)

            # Calculate the minimum total price using the min_price_greedy function
            min_sum = min_price_greedy(row_)

            with open(output_file, 'a+') as out_object:
                out_object.write(f"{str(min_sum)}\n")

        file_object.close()
    except FileNotFoundError as e:
        print("Input file not found.", e)
    except Exception as e:
        print("An error occurred:", str(e))


if __name__ == '__main__':
    main()
