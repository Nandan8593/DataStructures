'''
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Developers : Hari Hara Nandan, Siben Nayak, Rakesh N S
We have used Dijkstra's algorithm to return single source shortest path.
The below code takes O(logN) for heapification process after push or pop.operation, and for traversing the maze it takes O(rows*columns)
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

README:
execution steps:

python3 <filename.py> <inputPS05.txt>

e.g. python3 assignment_PS05_G105.py inputPS05.txt
'''

import os
import sys
class MinHeap:
    #Intialization
    def __init__(self):
        self.heap = []  
    #Check if empty
    def is_empty(self):
        return len(self.heap) == 0 
    #This will push into the heap and will do up heap bubbling
    def push(self, value, row, col):
        self.heap.append((value, row, col))
        self._bubble_up(len(self.heap) - 1)
        
    #This will pop the element and will do down heap bubbling
    def pop(self):
        if self.is_empty():
            raise IndexError("Heap is empty")
        self._swap(0, len(self.heap) - 1)
        value, row, col = self.heap.pop()
        self._bubble_down(0)
        return value, row, col
        
    #This will actually check if parent is greater than the pushed child. If yes it will try to swap parent with child, this process continuous recursively as up heap bubling
    def _bubble_up(self, index):
        parent = (index - 1) // 2
        while index > 0 and self.heap[parent][0] > self.heap[index][0]:
            self._swap(parent, index)
            index = parent
            parent = (index - 1) // 2
            
    #This will compare if children are smaller than parent, If yes it will recursively pushes the larger ones down in down heap bubling fashion
    def _bubble_down(self, index):
        while True:
            left = 2 * index + 1
            right = 2 * index + 2
            smallest = index
            if left < len(self.heap) and self.heap[left][0] < self.heap[smallest][0]:
                smallest = left
            if right < len(self.heap) and self.heap[right][0] < self.heap[smallest][0]:
                smallest = right
            if smallest != index:
                self._swap(smallest, index)
                index = smallest
            else:
                break
    
    #This is a utlity function created to do swapping
    def _swap(self, i, j):
        self.heap[i], self.heap[j] = self.heap[j], self.heap[i]


def dijkstra_maze(maze, source, destination):
    m = len(maze)
    n = len(maze[0])

    # Initialize distances array with infinity values
    distances = [[float('inf')] * n for _ in range(m)]

    # Initialize previous cells array for backtracking the path
    previous = [[None] * n for _ in range(m)]

    # Define directions for movement: up, down, left, right
    directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]

    # Start position and distance
    start_row, start_col = source
    distances[start_row][start_col] = maze[start_row][start_col]

    # Custom min heap for efficient extraction of minimum distance
    pq = MinHeap()
    pq.push(maze[start_row][start_col], start_row, start_col)

    # Dijkstra's algorithm
    while not pq.is_empty():
        dist, row, col = pq.pop()

        # Destination reached, break out of the loop
        if (row, col) == destination:
            break

        # Update distances for neighbors
        for dx, dy in directions:
            new_row, new_col = row + dx, col + dy

            # Check if the new position is within the maze bounds
            if 0 <= new_row < m and 0 <= new_col < n:
                new_dist = dist + maze[new_row][new_col]

                # Update distance if it's smaller than the current value
                if new_dist < distances[new_row][new_col]:
                    distances[new_row][new_col] = new_dist
                    previous[new_row][new_col] = (row, col)
                    pq.push(new_dist, new_row, new_col)

    # If destination distance is still infinity, there is no valid path
    if distances[destination[0]][destination[1]] == float('inf'):
        return None

    # Backtrack the path from destination to source
    path = []
    row, col = destination
    while (row, col) != source:
        path.append((row, col))
        row, col = previous[row][col]
    path.append(source)
    path.reverse()

    # Return the minimum path sum and path traversed
    return distances[destination[0]][destination[1]], path



def main(input_file):
    try:
        file_object=open(input_file)
        for i in file_object:
            maze,source,destination=i.split("|")[0].split(':')[1],i.split("|")[1].split(':')[1],i.split("|")[2].split(':')[1]
            maze=eval(maze)
            has_negative = any(num_ < 0 for row_ in maze for num_ in row_)
            if has_negative:
                print("ERROR:This Algorithm doesn't support negative weights.")
                exit(1)
            source=eval(source)
            has_negative_source = any(val < 0 for val in source)
            if has_negative_source:
                print("ERROR:This Algorithm doesn't support negative weights.")
                exit(1)
            destination=eval(destination)
            has_negative_destination = any(val < 0 for val in destination)
            if has_negative_destination:
                print("ERROR:This Algorithm doesn't support negative weights.")
                exit(1)
            min_sum,path=dijkstra_maze(maze,source,destination)
            output_file='outputPS05.txt'
            with open(output_file,'a+') as out_object:
                out_object.write(f"Shortest Path: {path}\n".format(path))
        file_object.close()
    except Exception as error:
        print(f"An error occurred: {str(error)}")
        
    
    

if __name__ == '__main__':
    try:
        output_file='outputPS05.txt'
        if os.path.exists(output_file):
            os.remove(output_file)
        main(sys.argv[1])
    except Exception as e:
        print(f"An error occurred: {str(e)}")

